# Food-Ordering-App-MERN
Demo - <a href="https://drive.google.com/file/d/1RJzLnoh63AlDz6dUwKgoZcZq9fA9gZwX/view?usp=drive_link">view video</a>
